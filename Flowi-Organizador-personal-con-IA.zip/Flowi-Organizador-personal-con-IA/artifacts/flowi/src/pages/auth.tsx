import { FormEvent, useState } from 'react';
import { ArrowRight, Check, Eye, EyeOff, Sparkles } from 'lucide-react';
import { Link, useLocation } from 'wouter';
import { supabase } from '@/lib/supabase';

export function AuthPage({ mode }: { mode: 'login' | 'register' }) {
  const [, setLocation] = useLocation();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');
  const isRegister = mode === 'register';

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    setMessage('');
    const response = isRegister
      ? await supabase.signUp({ nombre: name.trim(), email, password })
      : await supabase.signInWithPassword({ email, password });
    setBusy(false);
    if (response.error) {
      setMessage(response.error.message);
    } else if (isRegister && !response.data.session) {
      setMessage('Revisa tu correo para confirmar tu cuenta.');
    } else {
      setLocation('/');
    }
  }

  return (
    <main className="grain ambient-page grid min-h-[100dvh] bg-[hsl(var(--background))] lg:grid-cols-[minmax(420px,0.88fr)_1.12fr]">
      <section className="flowi-hero-panel relative hidden overflow-hidden bg-[#202c4c] p-12 text-[#fffaf0] lg:flex lg:flex-col lg:justify-between">
        <div className="absolute -right-24 -top-24 h-80 w-80 rounded-full bg-[#378ADD] opacity-75 blur-3xl" />
        <div className="absolute bottom-24 left-8 h-52 w-52 rounded-full bg-[#f5c96a] opacity-30 blur-3xl" />
        <Link href="/" className="relative z-10 flex w-fit items-center gap-2 text-2xl font-bold tracking-[-0.06em]" data-testid="link-auth-logo">
          Flow<span className="text-[#378ADD]">i</span>
        </Link>
        <div className="relative z-10 max-w-sm">
          <div className="mb-7 flex h-11 w-11 items-center justify-center rounded-2xl bg-[#f5c96a] text-[#202c4c]">
            <Sparkles size={21} />
          </div>
          <p className="mb-4 font-mono text-xs uppercase tracking-[0.2em] text-[#a9b8d6]">Tu espacio, a tu ritmo</p>
          <h1 className="font-serif text-5xl font-semibold leading-[.98] tracking-[-0.055em]">Menos ruido.<br />Más día para ti.</h1>
          <p className="mt-6 text-base leading-7 text-[#bdc9df]">Flowi guarda tus pendientes, ordena tus ideas y te devuelve una cosa valiosa: claridad.</p>
        </div>
        <div className="relative z-10 flex items-center gap-3 text-xs text-[#a9b8d6]"><Check size={15} className="text-[#f5c96a]" /> Hecho para avanzar sin prisa</div>
      </section>
      <section className="flex items-center justify-center px-5 py-10 sm:px-10">
        <div className="w-full max-w-[410px] flowi-enter">
          <div className="mb-12 flex items-center justify-between lg:hidden">
            <Link href="/" className="text-2xl font-bold tracking-[-0.06em]" data-testid="link-mobile-logo">Flow<span className="text-[#378ADD]">i</span></Link>
            <span className="rounded-full bg-[#e8f2fe] px-3 py-1 font-mono text-[10px] uppercase tracking-[.16em] text-[#378ADD]">Privado</span>
          </div>
          <p className="mb-3 font-mono text-xs uppercase tracking-[.18em] text-[hsl(var(--primary))]">{isRegister ? 'Primer paso' : 'Qué bueno verte'}</p>
          <h2 className="font-serif text-4xl font-semibold tracking-[-.055em] text-[hsl(var(--foreground))]">{isRegister ? 'Crea tu espacio.' : 'Vuelve a tu centro.'}</h2>
          <p className="mt-3 text-[15px] leading-6 text-[hsl(var(--muted-foreground))]">{isRegister ? 'Un lugar tranquilo para organizar lo que importa.' : 'Tus ideas y tu día te estaban esperando.'}</p>
          <form className="mt-9 space-y-5" onSubmit={submit}>
            {isRegister && <label className="block">
              <span className="mb-2 block text-sm font-semibold">Tu nombre</span>
              <input data-testid="input-name" required minLength={2} autoComplete="name" type="text" value={name} onChange={(event) => setName(event.target.value)} placeholder="¿Cómo te llamamos?" className="h-13 w-full rounded-2xl border border-[hsl(var(--input))] bg-[hsl(var(--card))] px-4 outline-none transition focus:border-[hsl(var(--primary))] focus:ring-4 focus:ring-[#378ADD]/10" />
            </label>}
            <label className="block">
              <span className="mb-2 block text-sm font-semibold">Correo electrónico</span>
              <input data-testid="input-email" required autoComplete="email" type="email" value={email} onChange={(event) => setEmail(event.target.value)} placeholder="tu@correo.com" className="h-13 w-full rounded-2xl border border-[hsl(var(--input))] bg-[hsl(var(--card))] px-4 outline-none transition focus:border-[hsl(var(--primary))] focus:ring-4 focus:ring-[#378ADD]/10" />
            </label>
            <label className="block">
              <span className="mb-2 block text-sm font-semibold">Contraseña</span>
              <span className="relative block">
                <input data-testid="input-password" required autoComplete={isRegister ? 'new-password' : 'current-password'} minLength={6} type={showPassword ? 'text' : 'password'} value={password} onChange={(event) => setPassword(event.target.value)} placeholder="Al menos 6 caracteres" className="h-13 w-full rounded-2xl border border-[hsl(var(--input))] bg-[hsl(var(--card))] px-4 pr-12 outline-none transition focus:border-[hsl(var(--primary))] focus:ring-4 focus:ring-[#378ADD]/10" />
                <button data-testid="button-toggle-password" type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-3.5 rounded-lg p-1 text-[hsl(var(--muted-foreground))] hover:text-[hsl(var(--foreground))]" aria-label="Mostrar contraseña">{showPassword ? <EyeOff size={18} /> : <Eye size={18} />}</button>
              </span>
            </label>
            {message && <p data-testid="status-auth-message" className="rounded-2xl bg-[#fff1ed] px-4 py-3 text-sm leading-5 text-[#a4493d]">{message}</p>}
            <button data-testid="button-submit-auth" disabled={busy} className="group flex h-13 w-full items-center justify-center gap-2 rounded-2xl bg-[#378ADD] font-semibold text-white shadow-[0_8px_18px_-8px_#378ADD] transition hover:-translate-y-0.5 disabled:opacity-60">
              {busy ? 'Un momento…' : isRegister ? 'Crear mi espacio' : 'Entrar a Flowi'} <ArrowRight size={17} className="transition-transform group-hover:translate-x-1" />
            </button>
          </form>
          <p className="mt-8 text-center text-sm text-[hsl(var(--muted-foreground))]">
            {isRegister ? '¿Ya tienes cuenta? ' : '¿Aún no tienes cuenta? '}
            <Link href={isRegister ? '/login' : '/register'} className="font-semibold text-[hsl(var(--primary))] hover:underline" data-testid="link-auth-switch">{isRegister ? 'Inicia sesión' : 'Crea una'}</Link>
          </p>
        </div>
      </section>
    </main>
  );
}