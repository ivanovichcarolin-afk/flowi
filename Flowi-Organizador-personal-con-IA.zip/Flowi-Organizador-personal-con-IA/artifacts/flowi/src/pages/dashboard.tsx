import { useEffect, useMemo, useState, type FormEvent } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import {
  Check, CheckCircle2, ChevronRight, Circle, Clock3, Coffee, Flame, ListPlus, LogOut, Menu, Plus, Send, Sparkles, Target, Trash2, UserRound, X, Zap,
} from 'lucide-react';
import {
  getGetDashboardQueryKey, getGetStatsQueryKey, getListTasksQueryKey, useCreateDayPlan, useCreatePomodoroSession, useCreateTask, useDeleteTask, useGetDashboard, useGetStats, useListTasks, useOrganizeBrainDump, useUpdateProfile, useUpdateTask,
} from '@workspace/api-client-react';
import type { BrainDumpResult, Task } from '@workspace/api-client-react';
import { supabase } from '@/lib/supabase';
import { useLocation } from 'wouter';

const dateFormatter = new Intl.DateTimeFormat('es-ES', { weekday: 'long', day: 'numeric', month: 'long' });
const shortDay = new Intl.DateTimeFormat('es-ES', { weekday: 'short' });

function SkeletonDashboard() {
  return <div className="space-y-6 p-5 md:p-10"><div className="skeleton h-8 w-56 rounded-xl" /><div className="grid gap-5 lg:grid-cols-[1.4fr_.85fr]"><div className="skeleton h-[430px] rounded-[24px]" /><div className="space-y-5"><div className="skeleton h-48 rounded-[24px]" /><div className="skeleton h-48 rounded-[24px]" /></div></div></div>;
}

type ProfileUser = { email: string; nombre: string; isPro: boolean; racha: number };

function AppSidebar({ user, open, onClose, onEditProfile }: { user?: ProfileUser; open: boolean; onClose: () => void; onEditProfile: () => void }) {
  const [, setLocation] = useLocation();
  async function logout() { await supabase.signOut(); setLocation('/login'); }
  const displayName = user?.nombre?.trim() || user?.email || 'Tu espacio';
  return <aside className={`fixed inset-y-0 left-0 z-40 flex w-[248px] flex-col bg-[#202c4c] px-5 py-6 text-[#fffaf0] transition-transform md:relative md:translate-x-0 ${open ? 'translate-x-0' : '-translate-x-full'}`}>
    <div className="flex items-center justify-between"><span className="text-[27px] font-bold tracking-[-.08em]">Flow<span className="text-[#378ADD]">i</span></span><button data-testid="button-close-menu" onClick={onClose} className="rounded-xl p-2 text-[#a9b8d6] hover:bg-[#2d3a5d] md:hidden"><X size={18} /></button></div>
    <div className="mt-14 space-y-2">
      <p className="px-3 pb-3 font-mono text-[10px] uppercase tracking-[.18em] text-[#8291b0]">Tu día</p>
      <button data-testid="button-nav-hoy" className="flex w-full items-center gap-3 rounded-2xl bg-[#2d3d61] px-3 py-3 text-sm font-semibold"><Target size={17} className="text-[#f5c96a]" /> Hoy <span className="ml-auto h-2 w-2 rounded-full bg-[#378ADD]" /></button>
    </div>
    <div className="mt-auto">
      <div className="mb-5 rounded-2xl border border-[#3a4868] bg-[#293755] p-4"><div className="flex items-center gap-2 text-xs font-semibold"><Sparkles size={14} className="text-[#f5c96a]" /> Plan Pro</div><p className="mt-2 text-xs leading-5 text-[#a9b8d6]">{user?.isPro ? 'Tu mente tiene espacio ilimitado.' : 'Más consultas para días con mucho por ordenar.'}</p>{!user?.isPro && <button data-testid="button-upgrade" onClick={() => setLocation('/')} className="mt-3 text-xs font-semibold text-[#f5c96a] hover:underline">Conocer Pro <ChevronRight className="inline" size={13} /></button>}</div>
      <div className="flex items-center gap-2 border-t border-[#3a4868] pt-4"><button data-testid="button-open-profile" onClick={onEditProfile} className="flex min-w-0 flex-1 items-center gap-3 rounded-xl p-1 text-left hover:bg-[#2d3a5d]"><div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-[#f5c96a] text-sm font-bold text-[#202c4c]">{displayName[0]?.toUpperCase() ?? 'T'}</div><div className="min-w-0 flex-1"><p className="truncate text-xs font-semibold">{displayName}</p><p className="truncate text-[10px] text-[#8291b0]">{user?.email ?? ''}</p><p className="mt-0.5 flex items-center gap-1 text-[11px] text-[#a9b8d6]"><Flame size={12} className="text-[#f5c96a]" /> {user?.racha ?? 0} días de racha</p></div><UserRound size={15} className="shrink-0 text-[#8291b0]" /></button><button data-testid="button-logout" onClick={logout} className="rounded-xl p-2 text-[#a9b8d6] hover:bg-[#2d3a5d] hover:text-white" aria-label="Cerrar sesión"><LogOut size={16} /></button></div>
    </div>
  </aside>;
}

function TaskList({ tasks }: { tasks: Task[] }) {
  const queryClient = useQueryClient();
  const updateTask = useUpdateTask();
  const deleteTask = useDeleteTask();
  const toggle = (task: Task) => updateTask.mutate({ id: task.id, data: { completada: !task.completada } }, { onSuccess: () => { void queryClient.invalidateQueries({ queryKey: getListTasksQueryKey() }); void queryClient.invalidateQueries({ queryKey: getGetDashboardQueryKey() }); } });
  const remove = (task: Task) => { if (window.confirm('¿Quitar esta tarea?')) deleteTask.mutate({ id: task.id }, { onSuccess: () => { void queryClient.invalidateQueries({ queryKey: getListTasksQueryKey() }); void queryClient.invalidateQueries({ queryKey: getGetDashboardQueryKey() }); } }); };
  if (!tasks.length) return <div data-testid="empty-tasks" className="flex min-h-[245px] flex-col items-center justify-center rounded-2xl border border-dashed border-[hsl(var(--border))] bg-[#fffaf0]/50 px-6 text-center"><div className="mb-3 flex h-11 w-11 items-center justify-center rounded-2xl bg-[#e8f2fe] text-[#378ADD]"><CheckCircle2 size={21} /></div><p className="font-serif text-lg font-semibold">Tu lista está en blanco</p><p className="mt-1 max-w-[240px] text-sm leading-5 text-[hsl(var(--muted-foreground))]">Es un buen momento para elegir qué merece tu energía hoy.</p></div>;
  return <div className="min-w-0 space-y-1">{tasks.map((task) => <div key={task.id} data-testid={`row-task-${task.id}`} className={`group flex min-w-0 items-center gap-3 rounded-2xl px-2 py-3 transition hover:bg-[#f8f3e7] ${task.completada ? 'opacity-55' : ''}`}><button data-testid={`button-toggle-task-${task.id}`} onClick={() => toggle(task)} className={`flex h-6 w-6 shrink-0 items-center justify-center rounded-full border-2 transition ${task.completada ? 'border-[#378ADD] bg-[#378ADD] text-white' : 'border-[#b8c0ce] hover:border-[#378ADD]'}`} aria-label={task.completada ? 'Marcar pendiente' : 'Completar tarea'}>{task.completada && <Check size={14} strokeWidth={3} />}</button><span data-testid={`text-task-${task.id}`} className={`min-w-0 flex-1 break-words text-sm ${task.completada ? 'text-[hsl(var(--muted-foreground))] line-through' : 'font-medium'}`}>{task.texto}</span>{task.prioridad === 'urgente' && <span data-testid={`badge-urgent-${task.id}`} className="shrink-0 rounded-full bg-[#fff0d4] px-2 py-1 font-mono text-[9px] uppercase tracking-wide text-[#ad6810]">Ahora</span>}<button data-testid={`button-delete-task-${task.id}`} onClick={() => remove(task)} className="shrink-0 rounded-lg p-2 text-[hsl(var(--muted-foreground))] opacity-0 transition hover:bg-[#fff1ed] hover:text-[#a4493d] group-hover:opacity-100" aria-label="Eliminar tarea"><Trash2 size={15} /></button></div>)}</div>;
}

function TasksCard({ tasks }: { tasks: Task[] }) {
  const [text, setText] = useState('');
  const [priority, setPriority] = useState<'normal' | 'urgente'>('normal');
  const queryClient = useQueryClient();
  const createTask = useCreateTask();
  function submit(event: FormEvent) { event.preventDefault(); if (!text.trim()) return; createTask.mutate({ data: { texto: text.trim(), prioridad: priority } }, { onSuccess: () => { setText(''); setPriority('normal'); void queryClient.invalidateQueries({ queryKey: getListTasksQueryKey() }); void queryClient.invalidateQueries({ queryKey: getGetDashboardQueryKey() }); } }); }
  const pending = tasks.filter((task) => !task.completada).length;
  return <section className="flowi-card rounded-[24px] border border-[hsl(var(--card-border))] bg-[hsl(var(--card))] p-5 md:p-7"><div className="mb-5 flex items-start justify-between"><div><div className="flex items-center gap-2"><ListPlus size={17} className="text-[#378ADD]" /><h2 className="font-serif text-2xl font-semibold tracking-[-.04em]">Lo que mueve tu día</h2></div><p data-testid="text-pending-count" className="mt-1 text-sm text-[hsl(var(--muted-foreground))]">{pending ? `${pending} ${pending === 1 ? 'pendiente' : 'pendientes'} por delante` : 'Todo en calma por aquí'}</p></div><span className="rounded-full bg-[#e8f2fe] px-3 py-1 font-mono text-[10px] font-medium uppercase tracking-[.12em] text-[#378ADD]">Hoy</span></div><TaskList tasks={tasks} /><form onSubmit={submit} className="mt-5 flex gap-2 border-t border-[hsl(var(--border))] pt-5"><input data-testid="input-new-task" value={text} onChange={(event) => setText(event.target.value)} placeholder="Añade algo a tu lista…" className="min-w-0 flex-1 rounded-xl border border-[hsl(var(--input))] bg-[#fffaf0] px-3.5 py-3 text-sm outline-none placeholder:text-[hsl(var(--muted-foreground))] focus:border-[#378ADD] focus:ring-4 focus:ring-[#378ADD]/10" /><button type="button" data-testid="button-toggle-priority" onClick={() => setPriority(priority === 'normal' ? 'urgente' : 'normal')} className={`rounded-xl px-3 text-xs font-semibold transition ${priority === 'urgente' ? 'bg-[#fff0d4] text-[#ad6810]' : 'bg-[hsl(var(--muted))] text-[hsl(var(--muted-foreground))]'}`}>{priority === 'urgente' ? 'Urgente' : 'Normal'}</button><button disabled={createTask.isPending} data-testid="button-add-task" className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-[#378ADD] text-white transition hover:-translate-y-0.5 disabled:opacity-50" aria-label="Añadir tarea"><Plus size={19} /></button></form></section>;
}

function AiPlanCard({ tasks }: { tasks: Task[] }) {
  const [result, setResult] = useState('');
  const createPlan = useCreateDayPlan();
  function createPlanNow() { createPlan.mutate({ data: { tasks: tasks.filter((task) => !task.completada).map((task) => task.texto) } }, { onSuccess: (response) => setResult(response.result) }); }
  return <section className="flowi-card relative overflow-hidden rounded-[24px] bg-[#ddecfb] p-6 text-[#202c4c]"><div className="flowi-orb absolute -right-12 -top-12 h-40 w-40 rounded-full bg-[#378ADD] opacity-10" /><div className="relative"><div className="flex items-center justify-between"><div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-[#378ADD] text-white"><Sparkles size={18} /></div><span className="flowi-glow-pill rounded-full bg-white/60 px-2.5 py-1 font-mono text-[9px] uppercase tracking-[.15em] text-[#3971a6]">IA de Flowi</span></div><h2 className="mt-5 font-serif text-2xl font-semibold tracking-[-.04em]">Dale forma a tu día</h2><p className="mt-2 max-w-[280px] text-sm leading-5 text-[#4c6686]">Un plan sencillo para que sepas por dónde empezar, sin pensarlo tanto.</p>{result ? <div data-testid="text-ai-plan-result" className="mt-5 whitespace-pre-line rounded-2xl bg-white/70 p-4 text-sm leading-6 text-[#304968]">{result}</div> : <button data-testid="button-create-day-plan" disabled={createPlan.isPending || !tasks.some((task) => !task.completada)} onClick={createPlanNow} className="mt-5 flex items-center gap-2 rounded-xl bg-[#202c4c] px-4 py-3 text-sm font-semibold text-white transition hover:-translate-y-0.5 disabled:cursor-not-allowed disabled:opacity-45">{createPlan.isPending ? 'Ordenando…' : 'Crear mi plan'} <ChevronRight size={16} /></button>}{result && <button data-testid="button-refresh-day-plan" onClick={() => setResult('')} className="mt-3 text-xs font-semibold text-[#3971a6] hover:underline">Volver a intentar</button>}</div></section>;
}

function BrainDumpCard() {
  const [text, setText] = useState('');
  const [result, setResult] = useState<BrainDumpResult | null>(null);
  const organize = useOrganizeBrainDump();
  function submit(event: FormEvent) { event.preventDefault(); if (!text.trim()) return; organize.mutate({ data: { text } }, { onSuccess: (response) => setResult(response) }); }
  const categories = [
    { label: 'Tareas', items: result?.tasks ?? [], Icon: ListPlus },
    { label: 'Citas', items: result?.appointments ?? [], Icon: Clock3 },
    { label: 'Para mirar luego', items: result?.concerns ?? [], Icon: Circle },
  ];
  return <section className="flowi-card rounded-[24px] border border-[hsl(var(--card-border))] bg-[hsl(var(--card))] p-5 md:p-7"><div className="flex items-start justify-between"><div><div className="flex items-center gap-2"><Zap size={17} className="text-[#d96759]" /><h2 className="font-serif text-2xl font-semibold tracking-[-.04em]">Saca todo de tu cabeza</h2></div><p className="mt-1 text-sm text-[hsl(var(--muted-foreground))]">Escribe sin ordenar. Flowi se encarga de separar las piezas.</p></div><span className="hidden rounded-full bg-[#fff0ed] px-3 py-1 font-mono text-[10px] uppercase tracking-[.12em] text-[#bb5e51] sm:block">Brain dump</span></div><form onSubmit={submit} className="mt-5"><textarea data-testid="input-brain-dump" value={text} onChange={(event) => setText(event.target.value)} placeholder="Todo lo que ronda por ahí… una llamada, una idea, algo que no quieres olvidar." rows={4} className="w-full resize-none rounded-2xl border border-[hsl(var(--input))] bg-[#fffaf0] p-4 text-sm leading-6 outline-none placeholder:text-[hsl(var(--muted-foreground))] focus:border-[#d96759] focus:ring-4 focus:ring-[#d96759]/10" /><div className="mt-3 flex items-center justify-between"><span className="text-xs text-[hsl(var(--muted-foreground))]">{text.length ? `${text.length} caracteres` : 'Sin filtros, sin juicios'}</span><button disabled={organize.isPending || !text.trim()} data-testid="button-organize-brain-dump" className="flex items-center gap-2 rounded-xl bg-[#d96759] px-4 py-2.5 text-sm font-semibold text-white transition hover:-translate-y-0.5 disabled:opacity-45">{organize.isPending ? 'Ordenando…' : 'Ordenar esto'} <Send size={14} /></button></div></form>{result && <div data-testid="panel-brain-dump-result" className="mt-5 border-t border-[hsl(var(--border))] pt-5"><p data-testid="text-brain-dump-summary" className="mb-3 rounded-2xl bg-[#fff8e8] px-4 py-3 text-sm leading-5 text-[#6f5835]">{result.result}</p><div className="grid gap-3 sm:grid-cols-3">{categories.map(({ label, items, Icon }) => <div key={label} className="rounded-2xl bg-[#f8f3e7] p-3"><div className="flex items-center gap-1.5 text-xs font-semibold"><Icon size={14} className="text-[#d96759]" /> {label}</div><ul className="mt-2 space-y-1.5 text-xs leading-4 text-[hsl(var(--muted-foreground))]">{items.length ? items.map((item, index) => <li key={`${item}-${index}`}>· {item}</li>) : <li className="text-[hsl(var(--muted-foreground))]">Nada por aquí</li>}</ul></div>)}</div></div>}</section>;
}

function FocusCard({ onCompleted }: { onCompleted: () => void }) {
  const [seconds, setSeconds] = useState(25 * 60);
  const [running, setRunning] = useState(false);
  const pomo = useCreatePomodoroSession();
  useEffect(() => { if (!running) return; const timer = window.setInterval(() => setSeconds((value) => { if (value <= 1) { window.clearInterval(timer); setRunning(false); pomo.mutate({ data: { duracion: 25 } }); onCompleted(); return 0; } return value - 1; }), 1000); return () => window.clearInterval(timer); }, [running]);
  const percent = ((25 * 60 - seconds) / (25 * 60)) * 100;
  return <section className="flowi-card rounded-[24px] bg-[#f5c96a] p-5 text-[#202c4c] md:p-6"><div className="flex items-center justify-between gap-3"><div className="flex min-w-0 items-center gap-2"><Coffee size={17} className="shrink-0" /><h2 className="truncate font-serif text-2xl font-semibold tracking-[-.04em]">Un rato de foco</h2></div><span className="shrink-0 font-mono text-[10px] uppercase tracking-[.15em] opacity-60">Pomodoro</span></div><div className="mt-5 flex flex-col items-center gap-5 min-[380px]:flex-row min-[380px]:items-center"><div className="relative flex h-[104px] w-[104px] shrink-0 items-center justify-center"><svg className="absolute inset-0 h-full w-full" viewBox="0 0 100 100"><circle cx="50" cy="50" r="45" fill="none" stroke="rgba(32,44,76,.13)" strokeWidth="4" /><circle cx="50" cy="50" r="45" fill="none" stroke="#202c4c" strokeWidth="4" strokeDasharray="283" strokeDashoffset={283 - (283 * percent) / 100} className="ring-progress" /></svg><span data-testid="text-focus-timer" className="font-mono text-lg font-medium">{String(Math.floor(seconds / 60)).padStart(2, '0')}:{String(seconds % 60).padStart(2, '0')}</span></div><div className="min-w-0"><p className="text-sm font-semibold">{running ? 'Solo una cosa.' : seconds < 1500 ? 'Buen ritmo.' : 'Veinticinco minutos.'}</p><p className="mt-1 max-w-[150px] text-xs leading-5 opacity-70">{running ? 'Las distracciones pueden esperar.' : 'Elige algo pequeño y dale tu atención.'}</p><button data-testid="button-toggle-focus" onClick={() => setRunning(!running)} className="mt-3 rounded-xl bg-[#202c4c] px-4 py-2 text-xs font-semibold text-[#fffaf0] transition hover:-translate-y-0.5">{running ? 'Pausar' : seconds < 1500 ? 'Continuar' : 'Empezar'}</button></div></div></section>;
}

function StatsCard({ stats }: { stats?: { completedThisWeek: number; streak: number; focusHours: number; dailyCompletions: { day: string; count: number }[] } }) {
  const values = stats?.dailyCompletions ?? [];
  const max = Math.max(1, ...values.map((item) => item.count));
  return <section className="flowi-card rounded-[24px] border border-[hsl(var(--card-border))] bg-[hsl(var(--card))] p-5 md:p-6"><div className="flex items-center justify-between"><div className="flex items-center gap-2"><Flame size={17} className="text-[#d96759]" /><h2 className="font-serif text-2xl font-semibold tracking-[-.04em]">Tu ritmo</h2></div><span className="font-mono text-[10px] uppercase tracking-[.13em] text-[hsl(var(--muted-foreground))]">7 días</span></div><div className="mt-5 grid grid-cols-3 gap-3"><div><p data-testid="stat-completed-week" className="font-serif text-2xl font-semibold">{stats?.completedThisWeek ?? 0}</p><p className="mt-1 text-[11px] text-[hsl(var(--muted-foreground))]">completadas</p></div><div><p data-testid="stat-streak" className="font-serif text-2xl font-semibold">{stats?.streak ?? 0}</p><p className="mt-1 text-[11px] text-[hsl(var(--muted-foreground))]">días seguidos</p></div><div><p data-testid="stat-focus-hours" className="font-serif text-2xl font-semibold">{stats?.focusHours ?? 0}h</p><p className="mt-1 text-[11px] text-[hsl(var(--muted-foreground))]">de foco</p></div></div><div className="mt-6 flex h-20 items-end gap-2">{(values.length ? values : Array.from({ length: 7 }, (_, index) => ({ day: String(index), count: 0 }))).map((item, index) => <div key={`${item.day}-${index}`} className="flex h-full flex-1 flex-col items-center justify-end gap-1.5"><div className={`w-full max-w-[22px] rounded-t-md transition-all ${item.count ? 'flowi-bar' : 'flowi-bar-empty'}`} style={{ height: `${Math.max(9, (item.count / max) * 57)}px` }} title={`${item.count} completadas`} /><span className="font-mono text-[9px] uppercase text-[hsl(var(--muted-foreground))]">{shortDay.format(new Date(item.day)).slice(0, 2)}</span></div>)}</div></section>;
}

function ProfileDialog({ user, onClose, onSaved }: { user: ProfileUser; onClose: () => void; onSaved: () => void }) {
  const [name, setName] = useState(user.nombre || '');
  const [error, setError] = useState('');
  const updateProfile = useUpdateProfile();

  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const trimmedName = name.trim();
    if (trimmedName.length < 2) {
      setError('Escribe un nombre de al menos 2 caracteres.');
      return;
    }
    setError('');
    updateProfile.mutate({ data: { nombre: trimmedName } }, {
      onSuccess: onSaved,
      onError: () => setError('No pudimos guardar tu nombre. Inténtalo de nuevo.'),
    });
  }

  return <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#202c4c]/45 p-5" role="dialog" aria-modal="true" aria-labelledby="profile-dialog-title">
    <div className="flowi-card w-full max-w-md rounded-[24px] border border-[hsl(var(--card-border))] bg-[hsl(var(--card))] p-6 shadow-2xl">
      <div className="flex items-start justify-between gap-4">
        <div><div className="flex items-center gap-2 text-[#378ADD]"><UserRound size={17} /><span className="font-mono text-[10px] uppercase tracking-[.16em]">Tu perfil</span></div><h2 id="profile-dialog-title" className="mt-3 font-serif text-3xl font-semibold tracking-[-.05em]">¿Cómo te llamamos?</h2><p className="mt-2 text-sm leading-5 text-[hsl(var(--muted-foreground))]">Tu nombre aparece en el saludo y en tu espacio. El correo sigue siendo tu forma de iniciar sesión.</p></div>
        <button data-testid="button-close-profile" type="button" onClick={onClose} className="rounded-xl p-2 text-[hsl(var(--muted-foreground))] hover:bg-[hsl(var(--muted))]" aria-label="Cerrar perfil"><X size={18} /></button>
      </div>
      <form className="mt-6 space-y-4" onSubmit={submit}>
        <label className="block"><span className="mb-2 block text-sm font-semibold">Nombre</span><input data-testid="input-profile-name" required minLength={2} maxLength={80} autoComplete="name" value={name} onChange={(event) => setName(event.target.value)} className="h-13 w-full rounded-2xl border border-[hsl(var(--input))] bg-[hsl(var(--card))] px-4 outline-none transition focus:border-[hsl(var(--primary))] focus:ring-4 focus:ring-[#378ADD]/10" /></label>
        <div><span className="mb-2 block text-sm font-semibold">Correo de acceso</span><p className="rounded-2xl bg-[hsl(var(--muted))] px-4 py-3 text-sm text-[hsl(var(--muted-foreground))]">{user.email}</p></div>
        {error && <p data-testid="status-profile-error" className="rounded-2xl bg-[#fff1ed] px-4 py-3 text-sm leading-5 text-[#a4493d]">{error}</p>}
        <div className="flex justify-end gap-2 pt-2"><button data-testid="button-cancel-profile" type="button" onClick={onClose} className="rounded-xl px-4 py-2.5 text-sm font-semibold text-[hsl(var(--muted-foreground))] hover:bg-[hsl(var(--muted))]">Cancelar</button><button data-testid="button-save-profile" disabled={updateProfile.isPending} className="rounded-xl bg-[#378ADD] px-4 py-2.5 text-sm font-semibold text-white transition hover:-translate-y-0.5 disabled:opacity-60">{updateProfile.isPending ? 'Guardando…' : 'Guardar nombre'}</button></div>
      </form>
    </div>
  </div>;
}

export function DashboardPage() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const [toast, setToast] = useState('');
  const queryClient = useQueryClient();
  const dashboardQuery = useGetDashboard();
  const tasksQuery = useListTasks();
  const statsQuery = useGetStats();
  const tasks = useMemo(() => dashboardQuery.data?.tasks ?? tasksQuery.data ?? [], [dashboardQuery.data?.tasks, tasksQuery.data,]);
  const dashboard = dashboardQuery.data;
  function focusCompleted() { setToast('Sesión guardada. Bien hecho.'); void queryClient.invalidateQueries({ queryKey: getGetDashboardQueryKey() }); void queryClient.invalidateQueries({ queryKey: getGetStatsQueryKey() }); window.setTimeout(() => setToast(''), 3000); }
  if (dashboardQuery.isLoading && !dashboardQuery.data) return <div className="flex min-h-[100dvh]"><AppSidebar open={false} onClose={() => undefined} onEditProfile={() => undefined} /><main className="flex-1"><SkeletonDashboard /></main></div>;
  if (dashboardQuery.isError && !dashboardQuery.data) return <div className="flex min-h-[100dvh]"><AppSidebar open={false} onClose={() => undefined} onEditProfile={() => undefined} /><main className="flex flex-1 items-center justify-center p-6"><div className="max-w-sm text-center"><div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-2xl bg-[#fff1ed] text-[#d96759]"><Zap size={22} /></div><h1 className="font-serif text-2xl font-semibold">No pudimos abrir tu día</h1><p className="mt-2 text-sm leading-6 text-[hsl(var(--muted-foreground))]">Comprueba tu conexión y vuelve a intentarlo.</p><button data-testid="button-retry-dashboard" onClick={() => void dashboardQuery.refetch()} className="mt-5 rounded-xl bg-[#378ADD] px-4 py-2.5 text-sm font-semibold text-white">Intentar de nuevo</button></div></main></div>;
  const firstName = dashboard?.user.nombre?.trim().split(/\s+/)[0] || dashboard?.user.email?.split('@')[0]?.split(/[._-]/)[0] || 'amiga';
  return <div className="grain ambient-page flex min-h-[100dvh] w-full min-w-0 bg-[hsl(var(--background))]"><AppSidebar user={dashboard?.user} open={menuOpen} onClose={() => setMenuOpen(false)} onEditProfile={() => setProfileOpen(true)} />{menuOpen && <button data-testid="button-mobile-overlay" onClick={() => setMenuOpen(false)} className="fixed inset-0 z-30 bg-[#202c4c]/40 md:hidden" aria-label="Cerrar menú" />}<main className="min-w-0 max-w-full flex-1"><header className="flex items-center justify-between px-5 py-5 md:px-10 md:py-7"><button data-testid="button-open-menu" onClick={() => setMenuOpen(true)} className="rounded-xl p-2 text-[hsl(var(--foreground))] md:hidden"><Menu size={21} /></button><div className="hidden md:block" /><div className="flex items-center gap-3"><span data-testid="status-ai-usage" className="flowi-glow-pill hidden rounded-full border border-[hsl(var(--border))] bg-[hsl(var(--card))] px-3 py-1.5 font-mono text-[10px] text-[hsl(var(--muted-foreground))] sm:block">{dashboard?.user.isPro ? 'Flowi Pro · sin límites' : `${dashboard?.user.consultasHoy ?? 0} / 5 consultas IA`}</span><button data-testid="button-header-profile" onClick={() => setProfileOpen(true)} className="h-9 w-9 rounded-full bg-[#f5c96a] p-2 text-center text-sm font-bold text-[#202c4c] md:hidden" aria-label="Abrir perfil">{firstName[0]?.toUpperCase()}</button></div></header><div className="mx-auto w-full max-w-[1220px] min-w-0 px-5 pb-12 md:px-10"><div className="flowi-enter mb-8 min-w-0"><p data-testid="text-current-date" className="font-mono text-[11px] uppercase tracking-[.18em] text-[hsl(var(--muted-foreground))]">{dateFormatter.format(new Date())}</p><h1 data-testid="text-greeting" className="mt-3 font-serif text-4xl font-semibold tracking-[-.06em] md:text-5xl">Buenos días, <span className="text-[#378ADD]">{firstName}.</span></h1><p className="mt-2 text-[15px] text-[hsl(var(--muted-foreground))]">Haz espacio para lo que sí quieres que pase.</p></div><div className="grid min-w-0 gap-5 lg:grid-cols-[1.35fr_.85fr]"><div className="flowi-enter flowi-delay-1 min-w-0"><TasksCard tasks={tasks} /></div><div className="flowi-enter flowi-delay-2 min-w-0 space-y-5"><AiPlanCard tasks={tasks} /><FocusCard onCompleted={focusCompleted} /></div></div><div className="mt-5 grid min-w-0 gap-5 lg:grid-cols-[1.35fr_.85fr]"><div className="flowi-enter flowi-delay-2 min-w-0"><BrainDumpCard /></div><div className="flowi-enter flowi-delay-3 min-w-0"><StatsCard stats={statsQuery.data} /></div></div></div></main>{toast && <div data-testid="status-focus-toast" className="fixed bottom-5 left-1/2 z-50 flex -translate-x-1/2 items-center gap-2 rounded-full bg-[#202c4c] px-4 py-3 text-sm font-semibold text-white shadow-xl"><CheckCircle2 size={16} className="text-[#f5c96a]" />{toast}</div>}{profileOpen && dashboard?.user && <ProfileDialog user={dashboard.user} onClose={() => setProfileOpen(false)} onSaved={() => { void queryClient.invalidateQueries({ queryKey: getGetDashboardQueryKey() }); setProfileOpen(false); }} />}</div>;
}