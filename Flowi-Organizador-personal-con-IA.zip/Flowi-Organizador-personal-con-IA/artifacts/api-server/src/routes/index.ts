import { Router, type IRouter } from "express";
import healthRouter from "./health";
import flowiRouter from "./flowi";

const router: IRouter = Router();

router.use(healthRouter);
router.use(flowiRouter);

export default router;
