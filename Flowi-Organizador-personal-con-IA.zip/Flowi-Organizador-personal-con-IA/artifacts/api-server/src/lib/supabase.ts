type SupabaseUser = {
  id: string;
  email?: string;
  user_metadata?: {
    nombre?: string;
  };
};

type RestOptions = {
  method?: "GET" | "POST" | "PATCH" | "DELETE";
  query?: Record<string, string | number | boolean | undefined>;
  body?: unknown;
  prefer?: string;
};

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseAnonKey = process.env.SUPABASE_ANON_KEY;

export function isSupabaseConfigured() {
  return Boolean(supabaseUrl && supabaseAnonKey);
}

export async function getSupabaseUser(token: string): Promise<SupabaseUser | null> {
  if (!supabaseUrl || !supabaseAnonKey) return null;
  const response = await fetch(`${supabaseUrl}/auth/v1/user`, {
    headers: {
      apikey: supabaseAnonKey,
      Authorization: `Bearer ${token}`,
    },
  });
  if (!response.ok) return null;
  return (await response.json()) as SupabaseUser;
}

export async function updateSupabaseUserMetadata(
  token: string,
  data: Record<string, string>,
) {
  if (!supabaseUrl || !supabaseAnonKey) {
    return { data: null, error: "Supabase no está configurado.", status: 503 };
  }
  const response = await fetch(`${supabaseUrl}/auth/v1/user`, {
    method: "PUT",
    headers: {
      apikey: supabaseAnonKey,
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ data }),
  });
  const raw = await response.text();
  let parsed: unknown = null;
  if (raw) {
    try {
      parsed = JSON.parse(raw);
    } catch {
      parsed = raw;
    }
  }
  if (!response.ok) {
    const message =
      typeof parsed === "object" && parsed && "message" in parsed
        ? String((parsed as { message: unknown }).message)
        : "Supabase rechazó la actualización del perfil.";
    return { data: null, error: message, status: response.status };
  }
  return { data: parsed as SupabaseUser, error: null, status: response.status };
}

export async function supabaseRest<T>(
  token: string,
  table: string,
  options: RestOptions = {},
): Promise<{ data: T | null; error: string | null; status: number }> {
  if (!supabaseUrl || !supabaseAnonKey) {
    return { data: null, error: "Supabase no está configurado.", status: 503 };
  }

  const url = new URL(`${supabaseUrl}/rest/v1/${table}`);
  for (const [key, value] of Object.entries(options.query ?? {})) {
    if (value !== undefined) url.searchParams.set(key, String(value));
  }

  const response = await fetch(url, {
    method: options.method ?? "GET",
    headers: {
      apikey: supabaseAnonKey,
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
      ...(options.prefer ? { Prefer: options.prefer } : {}),
    },
    ...(options.body === undefined ? {} : { body: JSON.stringify(options.body) }),
  });

  const raw = await response.text();
  let parsed: unknown = null;
  if (raw) {
    try {
      parsed = JSON.parse(raw);
    } catch {
      parsed = raw;
    }
  }

  if (!response.ok) {
    const message =
      typeof parsed === "object" && parsed && "message" in parsed
        ? String((parsed as { message: unknown }).message)
        : typeof parsed === "string"
          ? parsed
          : "Supabase rechazó la solicitud.";
    return { data: null, error: message, status: response.status };
  }

  return { data: parsed as T, error: null, status: response.status };
}
