---
name: LLM JSON responses
description: Durable parsing rule for structured responses returned by language models.
---

Treat structured JSON from language models as presentation-tolerant input: strip common Markdown code fences and extract the JSON object before parsing.

**Why:** Even when the prompt requests only JSON, models can return valid JSON inside a fenced `json` block, which otherwise looks like an empty or failed classification to the UI.

**How to apply:** Keep the API response contract strict after normalization, and preserve a visible fallback summary when parsing cannot recover structured fields.