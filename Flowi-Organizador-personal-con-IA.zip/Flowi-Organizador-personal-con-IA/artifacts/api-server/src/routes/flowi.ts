import { Router, type IRouter, type Request, type Response } from "express";
import {
  BrainDumpResult,
  CreateDayPlanBody,
  CreatePomodoroSessionBody,
  CreateTaskBody,
  GetDashboardResponse,
  GetStatsResponse,
  ListTasksResponse,
  OrganizeBrainDumpBody,
  OrganizeBrainDumpResponse,
  Task,
  UpdateProfileBody,
  UpdateTaskBody,
  UpdateTaskParams,
  UpdateProfileResponse,
} from "@workspace/api-zod";
import { requireFlowiAuth } from "../middlewares/flowi-auth";
import { isSupabaseConfigured, supabaseRest, updateSupabaseUserMetadata } from "../lib/supabase";

const router: IRouter = Router();
const AI_LIMIT = 5;

type DbProfile = {
  id: string;
  email: string;
  nombre: string;
  is_pro: boolean;
  consultas_hoy: number;
  fecha_consultas: string;
  racha: number;
  created_at: string;
};

type DbTask = {
  id: number;
  usuario_id: string;
  texto: string;
  prioridad: "normal" | "urgente";
  completada: boolean;
  completada_at?: string | null;
  created_at: string;
};

function todayIso() {
  return new Date().toISOString().slice(0, 10);
}

function toTask(task: DbTask) {
  return {
    id: Number(task.id),
    usuarioId: task.usuario_id,
    texto: task.texto,
    prioridad: task.prioridad,
    completada: task.completada,
    createdAt: task.created_at,
  };
}

function completionDate(task: DbTask) {
  return (task.completada_at || task.created_at).slice(0, 10);
}

function sendSupabaseError(res: Response, error: string | null, status: number) {
  res.status(status >= 400 ? status : 500).json({ error: error ?? "Error de Supabase." });
}

async function ensureProfile(req: Request) {
  const token = req.flowiToken!;
  const user = req.flowiUser!;
  const found = await supabaseRest<DbProfile[]>(token, "usuarios", {
    query: { select: "*", id: `eq.${user.id}`, limit: 1 },
  });
  if (found.error) return { error: found.error, status: found.status, profile: null };
  if (found.data?.[0]) {
    const profile = found.data[0];
    if (profile.fecha_consultas !== todayIso()) {
      const reset = await supabaseRest<DbProfile[]>(token, "usuarios", {
        method: "PATCH",
        query: { id: `eq.${user.id}` },
        body: { consultas_hoy: 0, fecha_consultas: todayIso() },
        prefer: "return=representation",
      });
      if (reset.error) return { error: reset.error, status: reset.status, profile: null };
      return { error: null, status: 200, profile: reset.data?.[0] ?? { ...profile, consultas_hoy: 0, fecha_consultas: todayIso() } };
    }
    return { error: null, status: 200, profile };
  }

  const created = await supabaseRest<DbProfile[]>(token, "usuarios", {
    method: "POST",
    body: { id: user.id, email: user.email ?? "", nombre: user.user_metadata?.nombre ?? "" },
    prefer: "return=representation",
  });
  return { error: created.error, status: created.status, profile: created.data?.[0] ?? null };
}

async function getTasks(req: Request) {
  return supabaseRest<DbTask[]>(req.flowiToken!, "tareas", {
    query: { select: "*", usuario_id: `eq.${req.flowiUser!.id}`, order: "completada.asc,created_at.desc" },
  });
}

function profileView(profile: DbProfile, user: { id: string; email?: string; user_metadata?: { nombre?: string } }) {
  return {
    id: user.id,
    email: profile.email || user.email || "",
    nombre: profile.nombre || user.user_metadata?.nombre || "",
    isPro: profile.is_pro,
    consultasHoy: profile.consultas_hoy,
    racha: profile.racha,
  };
}

router.use(requireFlowiAuth);

router.patch("/profile", async (req, res) => {
  const body = UpdateProfileBody.parse(req.body);
  const nombre = body.nombre.trim();
  const authUpdated = await updateSupabaseUserMetadata(req.flowiToken!, { nombre });
  if (authUpdated.error) return sendSupabaseError(res, authUpdated.error, authUpdated.status);

  const current = await ensureProfile(req);
  if (current.error || !current.profile) return sendSupabaseError(res, current.error, current.status);

  const updated = await supabaseRest<DbProfile[]>(req.flowiToken!, "usuarios", {
    method: "PATCH",
    query: { id: `eq.${req.flowiUser!.id}` },
    body: { nombre },
    prefer: "return=representation",
  });
  const missingNameColumn = updated.status === 400 && updated.error?.toLowerCase().includes("nombre");
  if (updated.error && !missingNameColumn) return sendSupabaseError(res, updated.error, updated.status);
  const savedProfile = updated.data?.[0] ?? { ...current.profile, nombre };
  res.json(UpdateProfileResponse.parse(profileView(savedProfile, {
    ...req.flowiUser!,
    user_metadata: { ...req.flowiUser!.user_metadata, nombre },
  })));
});

router.get("/dashboard", async (req, res) => {
  if (!isSupabaseConfigured()) {
    res.status(503).json({ error: "Configura Supabase para usar Flowi." });
    return;
  }
  const [{ profile, error: profileError, status: profileStatus }, tasks] = await Promise.all([
    ensureProfile(req),
    getTasks(req),
  ]);
  if (profileError || !profile) return sendSupabaseError(res, profileError, profileStatus);
  if (tasks.error || !tasks.data) return sendSupabaseError(res, tasks.error, tasks.status);

  const today = todayIso();
  const completedToday = tasks.data.filter((task) => task.completada && completionDate(task) === today).length;
  const sessions = await supabaseRest<{ duracion: number }[]>(req.flowiToken!, "sesiones_pomodoro", {
    query: { select: "duracion", usuario_id: `eq.${req.flowiUser!.id}`, fecha: `gte.${today}T00:00:00.000Z` },
  });
  const result = {
    user: profileView(profile, req.flowiUser!),
    tasks: tasks.data.map(toTask),
    completedToday,
    pendingCount: tasks.data.filter((task) => !task.completada).length,
    focusMinutesToday: sessions.data?.reduce((sum, session) => sum + Number(session.duracion), 0) ?? 0,
  };
  res.json(GetDashboardResponse.parse(result));
});

router.get("/stats", async (req, res) => {
  const [{ profile, error: profileError, status: profileStatus }, tasks, sessions] = await Promise.all([
    ensureProfile(req),
    getTasks(req),
    supabaseRest<{ duracion: number; fecha: string }[]>(req.flowiToken!, "sesiones_pomodoro", {
      query: { select: "duracion,fecha", usuario_id: `eq.${req.flowiUser!.id}`, order: "fecha.desc", limit: 1000 },
    }),
  ]);
  if (profileError || !profile) return sendSupabaseError(res, profileError, profileStatus);
  if (tasks.error || sessions.error) return sendSupabaseError(res, tasks.error ?? sessions.error, tasks.error ? tasks.status : sessions.status);

  const weekStart = new Date();
  weekStart.setHours(0, 0, 0, 0);
  weekStart.setDate(weekStart.getDate() - 6);
  const dailyCompletions = Array.from({ length: 7 }, (_, index) => {
    const day = new Date(weekStart);
    day.setDate(weekStart.getDate() + index);
    const key = day.toISOString().slice(0, 10);
    return { day: key, count: tasks.data?.filter((task) => task.completada && completionDate(task) === key).length ?? 0 };
  });
  const focusHours = (sessions.data?.filter((session) => new Date(session.fecha) >= weekStart).reduce((sum, session) => sum + Number(session.duracion), 0) ?? 0) / 60;
  res.json(GetStatsResponse.parse({
    completedThisWeek: dailyCompletions.reduce((sum, item) => sum + item.count, 0),
    streak: profile.racha,
    focusHours: Math.round(focusHours * 10) / 10,
    dailyCompletions,
  }));
});

router.get("/tasks", async (req, res) => {
  const tasks = await getTasks(req);
  if (tasks.error || !tasks.data) return sendSupabaseError(res, tasks.error, tasks.status);
  res.json(ListTasksResponse.parse(tasks.data.map(toTask)));
});

router.post("/tasks", async (req, res) => {
  const body = CreateTaskBody.parse(req.body);
  const created = await supabaseRest<DbTask[]>(req.flowiToken!, "tareas", {
    method: "POST",
    body: { usuario_id: req.flowiUser!.id, texto: body.texto, prioridad: body.prioridad ?? "normal" },
    prefer: "return=representation",
  });
  if (created.error || !created.data?.[0]) return sendSupabaseError(res, created.error, created.status);
  res.status(201).json(toTask(created.data[0]));
});

router.patch("/tasks/:id", async (req, res) => {
  const params = UpdateTaskParams.parse({ id: Number(req.params.id) });
  const body = UpdateTaskBody.parse(req.body);
  const taskBody = {
    ...(body.texto === undefined ? {} : { texto: body.texto }),
    ...(body.prioridad === undefined ? {} : { prioridad: body.prioridad }),
    ...(body.completada === undefined ? {} : {
      completada: body.completada,
      completada_at: body.completada ? new Date().toISOString() : null,
    }),
  };
  const updated = await supabaseRest<DbTask[]>(req.flowiToken!, "tareas", {
    method: "PATCH",
    query: { id: `eq.${params.id}`, usuario_id: `eq.${req.flowiUser!.id}` },
    body: taskBody,
    prefer: "return=representation",
  });
  const missingCompletionColumn = updated.status === 400 && updated.error?.toLowerCase().includes("completada_at");
  if (updated.error && missingCompletionColumn) {
    const { completada_at: _completadaAt, ...legacyTaskBody } = taskBody;
    const legacyUpdated = await supabaseRest<DbTask[]>(req.flowiToken!, "tareas", {
      method: "PATCH",
      query: { id: `eq.${params.id}`, usuario_id: `eq.${req.flowiUser!.id}` },
      body: legacyTaskBody,
      prefer: "return=representation",
    });
    if (legacyUpdated.error) return sendSupabaseError(res, legacyUpdated.error, legacyUpdated.status);
    if (!legacyUpdated.data?.[0]) return res.status(404).json({ error: "Tarea no encontrada." });
    return res.json(toTask(legacyUpdated.data[0]));
  }
  if (updated.error) return sendSupabaseError(res, updated.error, updated.status);
  if (!updated.data?.[0]) return res.status(404).json({ error: "Tarea no encontrada." });
  res.json(toTask(updated.data[0]));
});

router.delete("/tasks/:id", async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isFinite(id)) return res.status(400).json({ error: "ID de tarea inválido." });
  const deleted = await supabaseRest<unknown[]>(req.flowiToken!, "tareas", {
    method: "DELETE",
    query: { id: `eq.${id}`, usuario_id: `eq.${req.flowiUser!.id}` },
    prefer: "return=representation",
  });
  if (deleted.error) return sendSupabaseError(res, deleted.error, deleted.status);
  if (!deleted.data?.length) return res.status(404).json({ error: "Tarea no encontrada." });
  res.status(204).send();
});

async function consumeAiQuery(req: Request, res: Response) {
  const { profile, error, status } = await ensureProfile(req);
  if (error || !profile) {
    sendSupabaseError(res, error, status);
    return null;
  }
  if (!profile.is_pro && profile.consultas_hoy >= AI_LIMIT) {
    res.status(402).json({ error: "Alcanzaste tu límite diario — Pasate a Pro", consultasHoy: profile.consultas_hoy, limite: AI_LIMIT });
    return null;
  }
  const nextCount = profile.is_pro ? profile.consultas_hoy : profile.consultas_hoy + 1;
  if (!profile.is_pro) {
    const incremented = await supabaseRest<DbProfile[]>(req.flowiToken!, "usuarios", {
      method: "PATCH",
      query: { id: `eq.${req.flowiUser!.id}` },
      body: { consultas_hoy: nextCount },
      prefer: "return=representation",
    });
    if (incremented.error) {
      sendSupabaseError(res, incremented.error, incremented.status);
      return null;
    }
  }
  return { ...profile, consultas_hoy: nextCount };
}

async function askAnthropic(prompt: string) {
  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) throw new Error("ANTHROPIC_API_KEY no está configurada.");
  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "x-api-key": apiKey,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify({ model: "claude-sonnet-4-6", max_tokens: 8192, messages: [{ role: "user", content: prompt }] }),
  });
  const payload = (await response.json()) as { content?: Array<{ type: string; text?: string }>; error?: { message?: string } };
  if (!response.ok) throw new Error(payload.error?.message ?? "Anthropic rechazó la solicitud.");
  return payload.content?.filter((block) => block.type === "text").map((block) => block.text ?? "").join("") ?? "";
}

router.post("/ai/day-plan", async (req, res) => {
  const body = CreateDayPlanBody.parse(req.body);
  const profile = await consumeAiQuery(req, res);
  if (!profile) return;
  try {
    const result = await askAnthropic(`Eres Flowi, un organizador personal cálido y práctico. Organiza estas tareas pendientes en un plan realista para hoy. Responde en español con horarios sugeridos, prioridades y descansos. No inventes tareas.\n\nTareas:\n${body.tasks.map((task, index) => `${index + 1}. ${task}`).join("\n")}`);
    res.json({ result, consultasHoy: profile.consultas_hoy, isPro: profile.is_pro });
  } catch (error) {
    req.log.error({ err: error }, "Day plan AI request failed");
    res.status(502).json({ error: error instanceof Error ? error.message : "No pudimos generar el plan." });
  }
});

router.post("/ai/brain-dump", async (req, res) => {
  const body = OrganizeBrainDumpBody.parse(req.body);
  const profile = await consumeAiQuery(req, res);
  if (!profile) return;
  try {
    const result = await askAnthropic(`Eres Flowi. Analiza este volcado mental y devuelve SOLO JSON válido con esta forma exacta: {"summary":"string","tasks":["string"],"appointments":["string"],"concerns":["string"]}. Clasifica sin inventar información y usa español.\n\nVolcado mental:\n${body.text}`);
    let parsed: { summary?: string; tasks?: string[]; appointments?: string[]; concerns?: string[] };
    try {
      const normalized = result
        .trim()
        .replace(/^```(?:json)?\s*/i, "")
        .replace(/\s*```$/i, "");
      const jsonStart = normalized.indexOf("{");
      const jsonEnd = normalized.lastIndexOf("}");
      parsed = JSON.parse(normalized.slice(jsonStart >= 0 ? jsonStart : 0, jsonEnd >= jsonStart ? jsonEnd + 1 : undefined)) as typeof parsed;
    } catch {
      parsed = { summary: result, tasks: [], appointments: [], concerns: [] };
    }
    res.json(OrganizeBrainDumpResponse.parse({
      result: parsed.summary ?? result,
      tasks: parsed.tasks ?? [],
      appointments: parsed.appointments ?? [],
      concerns: parsed.concerns ?? [],
      consultasHoy: profile.consultas_hoy,
      isPro: profile.is_pro,
    }));
  } catch (error) {
    req.log.error({ err: error }, "Brain dump AI request failed");
    res.status(502).json({ error: error instanceof Error ? error.message : "No pudimos ordenar tu mente." });
  }
});

router.post("/pomodoro/sessions", async (req, res) => {
  const body = CreatePomodoroSessionBody.parse(req.body);
  const created = await supabaseRest<{ id: number; usuario_id: string; duracion: number; fecha: string }[]>(req.flowiToken!, "sesiones_pomodoro", {
    method: "POST",
    body: { usuario_id: req.flowiUser!.id, duracion: body.duracion },
    prefer: "return=representation",
  });
  if (created.error || !created.data?.[0]) return sendSupabaseError(res, created.error, created.status);
  const session = created.data[0];
  res.status(201).json({ id: Number(session.id), usuarioId: session.usuario_id, duracion: Number(session.duracion), fecha: session.fecha });
});

router.use((error: unknown, _req: Request, res: Response, next: () => void) => {
  if (error instanceof Error && error.name === "ZodError") {
    res.status(400).json({ error: "Revisá los datos enviados." });
    return;
  }
  next();
});

export default router;