---
name: Orval and Zod integer compatibility
description: OpenAPI integer schemas can generate unsupported zod.int() calls in this workspace.
---

Use `type: number` in the OpenAPI contract when targeting the current Zod/Orval combination; enforce integer semantics at the runtime boundary where needed.

**Why:** The workspace resolves Zod 3 while the installed Orval generator emits the Zod 4-style `z.int()` helper for OpenAPI integer fields, breaking the generated library typecheck.

**How to apply:** After changing `lib/api-spec/openapi.yaml`, run codegen and the library typecheck before wiring generated schemas into routes.