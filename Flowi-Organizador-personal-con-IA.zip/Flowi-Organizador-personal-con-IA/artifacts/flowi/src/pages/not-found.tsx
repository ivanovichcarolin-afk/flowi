import { ArrowLeft, Compass } from 'lucide-react';
import { Link } from 'wouter';

export default function NotFound() {
  return (
    <main className="grain flex min-h-[100dvh] items-center justify-center bg-[hsl(var(--background))] px-5">
      <div className="flowi-enter max-w-md text-center">
        <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-[22px] bg-[#ddecfb] text-[#378ADD]"><Compass size={28} /></div>
        <p className="mt-7 font-mono text-[11px] uppercase tracking-[.2em] text-[#378ADD]">Fuera de mapa</p>
        <h1 className="mt-3 font-serif text-4xl font-semibold tracking-[-.06em]">Esta página se tomó el día libre.</h1>
        <p className="mt-3 text-sm leading-6 text-[hsl(var(--muted-foreground))]">No encontramos lo que buscas, pero tu espacio sigue aquí.</p>
        <Link href="/" data-testid="link-not-found-home" className="mx-auto mt-7 flex w-fit items-center gap-2 rounded-xl bg-[#378ADD] px-4 py-3 text-sm font-semibold text-white transition hover:-translate-y-0.5"><ArrowLeft size={16} /> Volver a mi día</Link>
      </div>
    </main>
  );
}