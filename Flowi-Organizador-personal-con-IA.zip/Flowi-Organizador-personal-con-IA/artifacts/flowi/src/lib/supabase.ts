import { createClient, type Session } from '@supabase/supabase-js';

export type AuthSession = Session;

const url = import.meta.env.VITE_SUPABASE_URL as string | undefined;
const anonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined;
const client = url && anonKey
  ? createClient(url, anonKey, { auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true } })
  : null;

function getEmailRedirectUrl() {
  if (typeof window === 'undefined') return undefined;
  return new URL(import.meta.env.BASE_URL || '/', window.location.origin).toString();
}

export const supabase = {
  isConfigured: Boolean(client),
  async getSession() {
    if (!client) return { data: { session: null as AuthSession | null } };
    return client.auth.getSession();
  },
  async getAccessToken() {
    const { data } = await this.getSession();
    return data.session?.access_token ?? null;
  },
  async signInWithPassword(credentials: { email: string; password: string }) {
    if (!client) return { data: { session: null, user: null }, error: { message: 'Configura Supabase para iniciar sesión.' } };
    return client.auth.signInWithPassword(credentials);
  },
  async signUp(credentials: { email: string; password: string; nombre?: string }) {
    if (!client) return { data: { session: null, user: null }, error: { message: 'Configura Supabase para crear tu cuenta.' } };
    return client.auth.signUp({
      email: credentials.email,
      password: credentials.password,
      options: {
        emailRedirectTo: getEmailRedirectUrl(),
        data: credentials.nombre ? { nombre: credentials.nombre } : undefined,
      },
    });
  },
  async signOut() {
    if (client) await client.auth.signOut();
  },
  onAuthStateChange(callback: (session: AuthSession | null) => void) {
    if (!client) return { data: { subscription: { unsubscribe: () => undefined } } };
    const { data } = client.auth.onAuthStateChange((_event, session) => callback(session));
    return { data };
  },
};