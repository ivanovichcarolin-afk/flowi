import type { NextFunction, Request, Response } from "express";
import { getSupabaseUser } from "../lib/supabase";

declare global {
  namespace Express {
    interface Request {
      flowiToken?: string;
      flowiUser?: { id: string; email?: string; user_metadata?: { nombre?: string } };
    }
  }
}

export async function requireFlowiAuth(
  req: Request,
  res: Response,
  next: NextFunction,
) {
  const header = req.header("authorization");
  const token = header?.startsWith("Bearer ") ? header.slice(7) : "";
  if (!token) {
    res.status(401).json({ error: "Necesitas iniciar sesión." });
    return;
  }

  try {
    const user = await getSupabaseUser(token);
    if (!user) {
      res.status(401).json({ error: "Tu sesión expiró. Vuelve a iniciar sesión." });
      return;
    }
    req.flowiToken = token;
    req.flowiUser = user;
    next();
  } catch (error) {
    req.log.error({ err: error }, "Supabase auth validation failed");
    res.status(503).json({ error: "No pudimos validar tu sesión." });
  }
}